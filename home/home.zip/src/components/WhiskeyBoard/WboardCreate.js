import React, { useState } from 'react';
import axios from 'axios';

const WboardCreate = () => {
    const [formData, setFormData] = useState({
        wboardName: '',
        wboardInfo: '',
        wboardType: '',
        wboardOrigin: '',
        wboardAlcohol: '',
        wboardAge: '',
        wboardTip: '',
        wboardImg: '',
    });

    const [image, setImage] = useState(null);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleImageChange = (e) => {
        setImage(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formDataWithImage = new FormData();
        formDataWithImage.append('file', image);
        try {
            const uploadRes = await axios.post('/api/wboard/upload', formDataWithImage, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            const fileName = uploadRes.data;
            await axios.post('/api/wboard', {
                ...formData,
                wboardImg: fileName,
            });
            alert('Product added successfully');
        } catch (error) {
            console.error('Error adding product:', error);
            alert('Error adding product');
        }
    };

    return (
        <div>
            <h2>Add New Whiskey</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>위스키 이름</label>
                    <input
                        type="text"
                        name="wboardName"
                        value={formData.wboardName}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>위스키 정보</label>
                    <input
                        type="text"
                        name="wboardInfo"
                        value={formData.wboardInfo}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>위스키 타입</label>
                    <input
                        type="text"
                        name="wboardType"
                        value={formData.wboardType}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>위스키 원산지</label>
                    <input
                        type="text"
                        name="wboardOrigin"
                        value={formData.wboardOrigin}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>위스키 도수</label>
                    <input
                        type="text"
                        name="wboardAlcohol"
                        value={formData.wboardAlcohol}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>위스키 연도</label>
                    <input
                        type="text"
                        name="wboardAge"
                        value={formData.wboardAge}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>위스키 팁</label>
                    <input
                        type="text"
                        name="wboardTip"
                        value={formData.wboardTip}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>위스키 이미지</label>
                    <input
                        type="file"
                        onChange={handleImageChange}
                    />
                </div>
                <button type="submit">Add Product</button>
            </form>
        </div>
    );
};

export default WboardCreate;
