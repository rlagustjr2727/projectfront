import React, { useState, useEffect } from 'react';
import WboardService from '../../api/WboardService';

const WboardList = () => {
  const [wboards, setWboards] = useState([]);

  useEffect(() => {
    fetchWboards();
  }, []);

  const fetchWboards = async () => {
    try {
      const response = await WboardService.getWboards();
      setWboards(response.data);
    } catch (error) {
      console.error('Error fetching wboards:', error);
    }
  };

  return (
    <div>
      <h1>Wboard List</h1>
      <ul>
        {wboards.map(wboard => (
          <li key={wboard.id}>
            <h2>{wboard.wboardName}</h2>
            <p>{wboard.wboardInfo}</p>
            <p>{wboard.wboardTip}</p>
            <img src={`/uploads${wboard.wboardImg}`} alt={wboard.wboardName} />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default WboardList;
